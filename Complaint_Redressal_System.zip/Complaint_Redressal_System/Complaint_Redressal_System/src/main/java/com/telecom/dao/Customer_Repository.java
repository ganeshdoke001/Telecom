package com.telecom.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.telecom.model.Customer;

@Repository
public interface Customer_Repository extends JpaRepository<Customer, Long> 
{
	@Query(value="Select u from Customer u Where u.name=?1",nativeQuery=true)
	public Customer findByName(String name);
}
