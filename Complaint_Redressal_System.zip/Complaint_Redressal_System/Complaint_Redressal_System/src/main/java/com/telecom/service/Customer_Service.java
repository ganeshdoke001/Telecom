package com.telecom.service;

import java.util.List;
import java.util.Optional;

import com.telecom.model.Customer;

public interface Customer_Service 
{
	public List<Customer> list();
	public void delete(Customer customer);
	public Optional<Customer> getCustomer(long cust_Id);
	public Customer update(Customer customer);
	public Customer save(Customer customer);
	public Customer getCustomerByName(String name);
	
}
