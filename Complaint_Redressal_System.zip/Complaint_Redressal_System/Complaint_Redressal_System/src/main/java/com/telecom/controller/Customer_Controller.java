package com.telecom.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PostFilter;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.telecom.exception.ErrorMessage;
import com.telecom.exception.ResourceNotFoundException;
import com.telecom.model.Customer;
import com.telecom.service.Customer_Service;

@RestController
@RequestMapping("/api")

public class Customer_Controller 
{

	@Autowired
	private Customer_Service customer_Service;
	
	@GetMapping("/customer")
	
	public ResponseEntity<List<Customer>> getCustomers()
	{
		return new ResponseEntity<List<Customer>>(customer_Service.list(),HttpStatus.OK);
	}
	
	@GetMapping("/customer/{name}")
	@PostFilter("filterObject.name ==authentication.name")
	public ResponseEntity<Customer> getCustomerByName(@RequestParam("name") String name)
	{
		return new ResponseEntity<Customer>(customer_Service.getCustomerByName(name),HttpStatus.OK);
	}
	
	@GetMapping("/customer/{id}")
	public ResponseEntity<Customer> getCustomerByID(@PathVariable("id") long id)
	{
		return new ResponseEntity<Customer>(customer_Service.getCustomer(id).get(),HttpStatus.OK);
	}
	
	@PostMapping("/customer")
	public ResponseEntity<Customer> saveCustomer( @RequestBody Customer customer)
	{
		return new ResponseEntity<Customer>(customer_Service.save(customer),HttpStatus.CREATED) ;
		
	}
	
	@PutMapping("/customer")

	public ResponseEntity<Customer> updateCustomer(@RequestBody Customer customer)
	{
		return  new ResponseEntity<Customer>(customer_Service.update(customer),HttpStatus.CREATED) ;
		
	}
	@DeleteMapping("/customer/{name}")
	
	public ResponseEntity<?> delete(@PathVariable("name") String name,@RequestBody Customer customer)
	{
		if(name==customer_Service.getCustomerByName(name).getName())
		{
			customer_Service.delete(customer);
			return new ResponseEntity<String>("Customer is Deleted",HttpStatus.OK);
		}
		
		return new ResponseEntity<String>("Customer not found",HttpStatus.OK);
	}
	
	@ExceptionHandler
	public ResponseEntity<ErrorMessage > handleException(ResourceNotFoundException exc) {
		
		ErrorMessage  error = new ErrorMessage ();
		
		error.setStatus(HttpStatus.NOT_FOUND.value());
		error.setMessage(exc.getMessage());
		error.setTimeStamp(System.currentTimeMillis());
		
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	 }

	@ExceptionHandler
	public ResponseEntity<ErrorMessage > handleException(Exception exc) {
		
		ErrorMessage  error = new ErrorMessage ();
		
		error.setStatus(HttpStatus.BAD_REQUEST.value());
		error.setMessage(exc.getMessage());
		error.setTimeStamp(System.currentTimeMillis());
		
		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	}	
}
