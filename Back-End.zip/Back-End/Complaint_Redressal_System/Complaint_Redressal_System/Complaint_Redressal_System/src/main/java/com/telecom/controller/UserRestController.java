package com.telecom.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.telecom.model.User;
import com.telecom.service.UserService;



@RestController
@RequestMapping("/")
@EnableGlobalMethodSecurity(prePostEnabled=true)
@CrossOrigin( origins="http://localhost:4200")
public class UserRestController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@PreAuthorize("hasRole('ROLE_CUSTOMER') or hasRole('ROLE_MANAGER') or hasRole('ROLE_ENGINEER')")
	@GetMapping("/users")
	public List<User> getAllUsers(Authentication authentication) {
		
		return userService.findAllUsers();
		
	}
	
	@GetMapping("/")
	public String login()
	{
		return "Authantication succesfully";	
	}
	
	@PreAuthorize("hasRole('ROLE_MANAGER')")
	@PostMapping("/users")
	public ResponseEntity<User> saveusers(@RequestBody User newUser,Authentication auth) {
		//System.out.println(newUser.getUserName()+"  "+auth.getName());
	
		newUser.setPassword(this.bCryptPasswordEncoder.encode(newUser.getPassword()));
		return new ResponseEntity<User>(userService.saveUser(newUser),HttpStatus.CREATED);
	}
	
	
	@PreAuthorize("@userSecurity.hasUserId(authentication,#userId)")
	@GetMapping("/users/{userId}")
	public ResponseEntity<User> getUserById(@PathVariable("userId") int userId, Authentication authentication) {
		//System.out.println("Inside getuserbyid method");
		return new ResponseEntity<User>(userService.findUserById(userId).get(),HttpStatus.CONTINUE);
		
	}
	
	@PutMapping("/users/{userId}")
	public ResponseEntity<User> updateUser(@PathVariable("userId") int UserId,@RequestBody User newUser) {
		return new ResponseEntity<User> (userService.updateUser(UserId,newUser),HttpStatus.ACCEPTED);
		
	}
	
	@DeleteMapping("/users/{userId}")
	public ResponseEntity<Object> deleteUser(@PathVariable("userId") int UserId) {
		 userService.deleteUser(UserId);
		 return new ResponseEntity<Object>(HttpStatus.NO_CONTENT);
		
	}
	
	@GetMapping("/users/search")
	@PostAuthorize("returnObject.body.userName==authenticated.user")
	public ResponseEntity<User> userDetails(Authentication authentication, @RequestParam("cname") String cName) throws Exception {
		//System.out.println(authentication.getName().toString());
		User User=userService.findByUserName(cName);
		if(User==null) {
			ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
		}
		return ResponseEntity.ok().body(User);
		
	}
}
