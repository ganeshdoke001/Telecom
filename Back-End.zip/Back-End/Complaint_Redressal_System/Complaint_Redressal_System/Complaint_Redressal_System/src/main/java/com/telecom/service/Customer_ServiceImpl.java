package com.telecom.service;

import java.util.List;


import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.telecom.dao.Customer_Repository;
import com.telecom.model.Customer;

@Service
@Transactional
public class Customer_ServiceImpl implements Customer_Service 
{

	@Autowired
	private Customer_Repository customer_Repository;

	@Override
	public List<Customer> list() {
		// TODO Auto-generated method stub
		return customer_Repository.findAll();
	}

	@Override
	public Customer update(Customer customer) {
		// TODO Auto-generated method stub
		return customer_Repository.save(customer);
	}

	@Override
	public Customer save(Customer customer) {
		// TODO Auto-generated method stub
		return customer_Repository.save(customer);
	}

	


	@Override
	public Customer getCustomer(long cust_Id) {
		// TODO Auto-generated method stub
		return customer_Repository.findById(cust_Id).get();
	}
	

	@Override
	public void deleteById(long id) {
		// TODO Auto-generated method stub
		customer_Repository.deleteById(id);
		
	}

	
	
}
