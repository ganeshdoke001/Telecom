package com.telecom;


import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.telecom.dao.Customer_Repository;
import com.telecom.model.Customer;
import com.telecom.service.Customer_Service;


@SpringBootTest
class ComplaintRedressalSystemApplicationTests
{
	@Autowired 
	private Customer_Service customer_Service;
	
	@MockBean
	private Customer_Repository customer_Repository;
	
	
	@Test
	public void getCustomersTest()
	{
		when(customer_Repository.findAll()).thenReturn(Stream
				.of(new Customer(1L,"Ganesh",413229L,7709952688L,"ganeshdoke1999@gmail.com","At.Beed","not working proper","raised"),
						new Customer(2L,"Mohan",413221L,9098877656L,"mohan1999@gmail.com","At.Beed","not working proper","raised"))
				.collect(Collectors.toList()));
		assertEquals(2, customer_Service.list().size());	
	}
	
	
	

	
	@Test
	public void savecustomerTest() {
		Customer customer = new Customer(1L,"Ganesh",413229L,7709952688L,"ganeshdoke1999@gmail.com","At.Beed","not working proper","raised");
		when(customer_Repository.save(customer)).thenReturn(customer);
		assertEquals(customer, customer_Service.save(customer));
	}

	@Test
	public void deleteUserTest() {
		Customer customer = new Customer(1L,"Ganesh",413229L,7709952688L,"ganeshdoke1999@gmail.com","At.Beed","not working proper","raised");
		when(customer_Repository.save(customer)).thenReturn(customer);
		customer_Service.deleteById(1l);
		verify(customer_Repository, times(1)).deleteById(1l);
	}
}
